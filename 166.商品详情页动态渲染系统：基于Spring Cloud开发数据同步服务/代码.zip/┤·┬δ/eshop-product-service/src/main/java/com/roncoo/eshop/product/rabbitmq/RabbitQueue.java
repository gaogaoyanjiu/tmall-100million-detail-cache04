package com.roncoo.eshop.product.rabbitmq;

public interface RabbitQueue {

	public static final String DATA_CHANGE_QUEUE = "data-change-queue";
	
}
